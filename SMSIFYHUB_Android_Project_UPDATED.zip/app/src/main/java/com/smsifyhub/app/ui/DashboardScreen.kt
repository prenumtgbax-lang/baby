package com.smsifyhub.app.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    viewModel: SmsifyViewModel,
    onOpenConsole: () -> Unit,
    onToggleFloatingPopup: (Boolean) -> Unit
) {
    val sessionState by viewModel.sessionState.collectAsStateWithLifecycle()
    val floatingEnabled by viewModel.floatingPopupEnabled.collectAsStateWithLifecycle()
    val context = LocalContext.current
    var inputTargetRange by remember { mutableStateOf("23278XXX") }

    val primaryBlue = Color(0xFF0284C7)
    val textPrimary = Color(0xFF0F172A)
    val textSecondary = Color(0xFF64748B)
    val cardBg = Color.White
    val cardBorder = Color(0xFFE2E8F0)
    val orangeAccent = Color(0xFFEA580C)

    val quickRanges = listOf("23278XXX", "23762XXX", "22465XXX", "2290145XXX", "22897XXX")

    fun copyText(label: String, text: String) {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText(label, text)
        clipboard.setPrimaryClip(clip)
        Toast.makeText(context, "$label copied!", Toast.LENGTH_SHORT).show()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF8FAFC))
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(12.dp))

        // A. SMSIFYHUB TITLE AT THE TOP (Clean White/Dark Theme)
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(10.dp)
                    .clip(CircleShape)
                    .background(primaryBlue)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "SMSIFYHUB",
                fontSize = 28.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 2.sp,
                color = textPrimary
            )
        }
        Text(
            text = "NEXT-GEN SMS OTP RECEPTOR",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = primaryBlue,
            letterSpacing = 2.sp
        )

        Spacer(modifier = Modifier.height(16.dp))

        // B. FLOATING POPUP ON/OFF TOGGLE
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = cardBg),
            border = BorderStroke(1.dp, if (floatingEnabled) primaryBlue else cardBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.PictureInPicture,
                        contentDescription = "Floating Overlay",
                        tint = if (floatingEnabled) primaryBlue else textSecondary,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "FLOATING POPUP WINDOW",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = textPrimary
                        )
                        Text(
                            text = if (floatingEnabled) "Active • Close to Icon • Draggable" else "Disabled (Tap switch to enable)",
                            fontSize = 11.sp,
                            color = textSecondary
                        )
                    }
                }

                Switch(
                    checked = floatingEnabled,
                    onCheckedChange = { onToggleFloatingPopup(it) },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.White,
                        checkedTrackColor = primaryBlue,
                        uncheckedTrackColor = Color(0xFFE2E8F0)
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // C. GET NUMBER SECTION
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = cardBg),
            border = BorderStroke(1.dp, cardBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "GET NUMBER SECTION",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF7C3AED),
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = inputTargetRange,
                    onValueChange = { inputTargetRange = it },
                    label = { Text("Target Range", color = textSecondary) },
                    placeholder = { Text("e.g. 23278XXX", color = Color.Gray) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = textPrimary,
                        unfocusedTextColor = textPrimary,
                        focusedBorderColor = primaryBlue,
                        unfocusedBorderColor = cardBorder
                    )
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Quick Range Chips
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    quickRanges.take(4).forEach { range ->
                        SuggestionChip(
                            onClick = { inputTargetRange = range },
                            label = { Text(range, fontSize = 10.sp, fontWeight = FontWeight.Bold) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Button(
                    onClick = { viewModel.requestNumber(inputTargetRange) },
                    enabled = !sessionState.isLoading,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = primaryBlue)
                ) {
                    if (sessionState.isLoading) {
                        CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("GENERATING NUMBER...")
                    } else {
                        Icon(imageVector = Icons.Default.PhoneIphone, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("GET NUMBER", fontWeight = FontWeight.Bold)
                    }
                }

                if (sessionState.phoneNumber.isNotBlank()) {
                    Spacer(modifier = Modifier.height(14.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFFF1F5F9))
                            .border(1.dp, primaryBlue, RoundedCornerShape(12.dp))
                            .padding(14.dp)
                    ) {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "GENERATED NUMBER",
                                    fontSize = 11.sp,
                                    color = textSecondary
                                )
                                Text(
                                    text = "SESSION: #${sessionState.sessionId}",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = primaryBlue
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = sessionState.phoneNumber,
                                fontSize = 22.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = textPrimary,
                                fontFamily = FontFamily.Monospace
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Button(
                                onClick = { copyText("Phone Number", sessionState.phoneNumber) },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = primaryBlue)
                            ) {
                                Icon(imageVector = Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("COPY NUMBER")
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // D. OTP RECEIVING SECTION
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = cardBg),
            border = BorderStroke(
                1.dp,
                if (sessionState.status == "received") orangeAccent else cardBorder
            ),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "OTP RECEIVING SECTION",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = orangeAccent,
                        letterSpacing = 1.sp
                    )

                    if (sessionState.status == "waiting") {
                        Text(
                            text = "${sessionState.elapsedSeconds}s",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = primaryBlue
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                when (sessionState.status) {
                    "waiting" -> {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0xFFFFF7ED))
                                .border(1.dp, Color(0xFFFDBA74), RoundedCornerShape(12.dp))
                                .padding(16.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                CircularProgressIndicator(color = orangeAccent, modifier = Modifier.size(36.dp))
                                Spacer(modifier = Modifier.height(8.dp))
                                Text("Waiting for OTP...", fontWeight = FontWeight.Bold, color = textPrimary)
                                Text("Polling active session live without delay", fontSize = 11.sp, color = textSecondary)
                            }
                        }
                    }
                    "received" -> {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0xFFFFF7ED))
                                .border(2.dp, orangeAccent, RoundedCornerShape(12.dp))
                                .padding(16.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("⚡ OTP RECEIVED INSTANTLY", color = orangeAccent, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = sessionState.otp,
                                    fontSize = 32.sp,
                                    fontWeight = FontWeight.Black,
                                    letterSpacing = 4.sp,
                                    color = orangeAccent,
                                    fontFamily = FontFamily.Monospace
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                                Button(
                                    onClick = { copyText("OTP Code", sessionState.otp) },
                                    colors = ButtonDefaults.buttonColors(containerColor = orangeAccent),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Icon(imageVector = Icons.Default.ContentCopy, contentDescription = null)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("COPY OTP", fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                    else -> {
                        Text(
                            text = if (sessionState.phoneNumber.isBlank()) "Generate a number above to begin waiting for OTP" else "Session: ${sessionState.status}",
                            fontSize = 12.sp,
                            color = textSecondary
                        )
                    }
                }

                if (sessionState.smsText.isNotBlank()) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(text = "Message: " + sessionState.smsText, fontSize = 12.sp, color = textPrimary)
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedButton(
                        onClick = { copyText("SMS Message", sessionState.smsText) },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("COPY MESSAGE")
                    }
                }

                // Check OTP Manually & Stop Session Buttons (100% WORKING)
                if (sessionState.phoneNumber.isNotBlank() && sessionState.otp.isBlank()) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = {
                                viewModel.refreshOtpManual()
                                Toast.makeText(context, "Checking operator gateway...", Toast.LENGTH_SHORT).show()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = primaryBlue),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(imageVector = Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Check OTP", fontSize = 12.sp)
                        }
                        OutlinedButton(
                            onClick = {
                                if (sessionState.status == "waiting") {
                                    viewModel.stopWaiting()
                                    Toast.makeText(context, "Session stopped.", Toast.LENGTH_SHORT).show()
                                } else {
                                    viewModel.requestNumber(inputTargetRange)
                                }
                            },
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(if (sessionState.status == "waiting") "Stop Session" else "Restart", fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // E. LIVE CONSOLE BUTTON
        Button(
            onClick = {
                viewModel.loadConsoleFeed()
                onOpenConsole()
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0F172A))
        ) {
            Icon(imageVector = Icons.Default.Terminal, contentDescription = null, tint = Color.White)
            Spacer(modifier = Modifier.width(8.dp))
            Text("LIVE CONSOLE", fontWeight = FontWeight.Bold, color = Color.White, letterSpacing = 1.sp)
        }

        Spacer(modifier = Modifier.height(20.dp))

        // DEVELOPER INFO AT THE BOTTOM (@YourDomains - Fixed!)
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .clip(RoundedCornerShape(12.dp))
                .clickable {
                    try {
                        val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/YourDomains"))
                        context.startActivity(browserIntent)
                    } catch (_: Exception) {
                        Toast.makeText(context, "Developer: @YourDomains", Toast.LENGTH_SHORT).show()
                    }
                }
                .padding(8.dp)
        ) {
            Text(
                text = "Developer Contact: @YourDomains",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = primaryBlue
            )
            Text(
                text = "Tap to contact on Telegram (t.me/YourDomains)",
                fontSize = 11.sp,
                color = textSecondary
            )
        }

        Spacer(modifier = Modifier.height(16.dp))
    }
}
