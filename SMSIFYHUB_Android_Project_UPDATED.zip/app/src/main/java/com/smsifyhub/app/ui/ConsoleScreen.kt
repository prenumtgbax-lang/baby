package com.smsifyhub.app.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ConsoleScreen(
    viewModel: SmsifyViewModel,
    onBack: () -> Unit
) {
    val consoleState by viewModel.consoleState.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val primaryBlue = Color(0xFF0284C7)
    val textPrimary = Color(0xFF0F172A)
    val textSecondary = Color(0xFF64748B)
    val cardBorder = Color(0xFFE2E8F0)

    // Load initial feed once upon entry (NO automatic periodic loop)
    LaunchedEffect(Unit) {
        if (consoleState.rawJson.isBlank()) {
            viewModel.loadConsoleFeed()
        }
    }

    fun copyText(label: String, text: String) {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText(label, text)
        clipboard.setPrimaryClip(clip)
        Toast.makeText(context, "$label copied!", Toast.LENGTH_SHORT).show()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF8FAFC))
            .padding(16.dp)
    ) {
        // Top Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) {
                    Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back", tint = textPrimary)
                }
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "LIVE CONSOLE",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Black,
                    color = textPrimary,
                    letterSpacing = 1.sp
                )
            }

            // Top Refresh Button (Manual refresh)
            IconButton(onClick = {
                viewModel.loadConsoleFeed()
                Toast.makeText(context, "Refreshing console...", Toast.LENGTH_SHORT).show()
            }) {
                Icon(imageVector = Icons.Default.Refresh, contentDescription = "Refresh", tint = primaryBlue)
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Stats Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Card(
                modifier = Modifier.weight(1f),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, cardBorder)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text("LATENCY", fontSize = 10.sp, color = textSecondary, fontWeight = FontWeight.Bold)
                    Text("${consoleState.responseTimeMs} ms", fontWeight = FontWeight.Bold, color = primaryBlue)
                }
            }

            Card(
                modifier = Modifier.weight(1f),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, cardBorder)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text("TOTAL HITS", fontSize = 10.sp, color = textSecondary, fontWeight = FontWeight.Bold)
                    Text("${consoleState.totalHits}", fontWeight = FontWeight.Bold, color = textPrimary)
                }
            }

            Card(
                modifier = Modifier.weight(1f),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, cardBorder)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text("RANGES", fontSize = 10.sp, color = textSecondary, fontWeight = FontWeight.Bold)
                    Text("${consoleState.activeRanges.size}", fontWeight = FontWeight.Bold, color = Color(0xFF7C3AED))
                }
            }
        }

        // Active Ranges (Click to copy)
        if (consoleState.activeRanges.isNotEmpty()) {
            Spacer(modifier = Modifier.height(10.dp))
            Text("ACTIVE RANGES (TAP TO COPY):", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = textSecondary)
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                consoleState.activeRanges.take(4).forEach { range ->
                    SuggestionChip(
                        onClick = { copyText("Range", range) },
                        label = { Text(range, fontSize = 10.sp, fontWeight = FontWeight.Bold) }
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Actions
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = { copyText("Console JSON", consoleState.rawJson) },
                enabled = consoleState.rawJson.isNotBlank(),
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = primaryBlue)
            ) {
                Icon(imageVector = Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("COPY RESPONSE", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }

            OutlinedButton(
                onClick = onBack,
                modifier = Modifier.weight(0.7f)
            ) {
                Text("BACK", fontSize = 11.sp)
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // JSON View
        Box(
            modifier = Modifier
                .fillMaxSize()
                .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(12.dp))
                .background(Color(0xFF0F172A))
                .padding(12.dp)
                .verticalScroll(rememberScrollState())
        ) {
            if (consoleState.isLoading) {
                CircularProgressIndicator(
                    color = Color(0xFF38BDF8),
                    modifier = Modifier.align(Alignment.Center)
                )
            } else if (consoleState.errorMessage.isNotBlank()) {
                Text(
                    text = "Error: " + consoleState.errorMessage,
                    color = Color(0xFFF87171),
                    modifier = Modifier.align(Alignment.Center)
                )
            } else {
                Text(
                    text = if (consoleState.rawJson.isNotBlank()) consoleState.rawJson else "No console response loaded. Tap Refresh above.",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    color = Color(0xFF38BDF8)
                )
            }
        }
    }
}
