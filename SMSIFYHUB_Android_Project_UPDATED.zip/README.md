# SMSIFYHUB - Android Application (Kotlin & Jetpack Compose)

Developer: PARANTO
Email: parantobaby@gmail.com

## How to Build in Android Studio & GitHub Actions:

1. Open Android Studio.
2. Select **File > Open...** and select this directory (`SMSIFYHUB`).
3. Android Studio will automatically sync with Gradle 8.9 and Android Gradle Plugin 8.7.0.
4. Run `./gradlew assembleDebug` to build the APK.

### Project Features:
- Autonomous OTP receptor with real-time polling
- Draggable Floating Popup Window (SYSTEM_ALERT_WINDOW)
- Live Console feed with metrics and active ranges
- High-priority Heads-up sound notifications for incoming OTPs
- 100% compliant AndroidManifest.xml and Gradle 8.9 configuration
