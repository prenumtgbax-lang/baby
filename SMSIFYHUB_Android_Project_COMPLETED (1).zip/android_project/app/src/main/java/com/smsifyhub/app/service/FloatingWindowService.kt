package com.smsifyhub.app.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import androidx.compose.ui.platform.ComposeView
import androidx.core.app.NotificationCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.smsifyhub.app.MainActivity
import com.smsifyhub.app.data.ApiService
import com.smsifyhub.app.ui.FloatingPopupView
import com.smsifyhub.app.ui.FloatingSessionState
import com.smsifyhub.app.util.NotificationHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class FloatingWindowService : Service(), LifecycleOwner, ViewModelStoreOwner, SavedStateRegistryOwner {

    companion object {
        const val ACTION_SHOW = "ACTION_SHOW"
        const val ACTION_HIDE = "ACTION_HIDE"
        const val ACTION_STOP = "ACTION_STOP"
        const val CHANNEL_ID = "smsify_floating_channel"
        const val NOTIFICATION_ID = 2026
    }

    private lateinit var windowManager: WindowManager
    private var floatingView: ComposeView? = null
    private lateinit var params: WindowManager.LayoutParams

    private val serviceJob = SupervisorJob()
    private val serviceScope = CoroutineScope(Dispatchers.Main + serviceJob)

    private val lifecycleRegistry = LifecycleRegistry(this)
    private val appViewModelStore = ViewModelStore()
    private val savedStateRegistryController = SavedStateRegistryController.create(this)

    private val api = ApiService.create()
    private val apiKey = "smsify_7ee5a9cfa1a113e6d7b799ea"
    private lateinit var notificationHelper: NotificationHelper

    private var pollingJob: Job? = null

    override val lifecycle: Lifecycle get() = lifecycleRegistry
    override val viewModelStore: ViewModelStore get() = appViewModelStore
    override val savedStateRegistry: SavedStateRegistry get() = savedStateRegistryController.savedStateRegistry

    override fun onCreate() {
        super.onCreate()
        savedStateRegistryController.performRestore(null)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_START)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_RESUME)

        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        notificationHelper = NotificationHelper(this)

        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildForegroundNotification())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_SHOW -> showFloatingWindow()
            ACTION_HIDE -> hideFloatingWindow()
            ACTION_STOP -> {
                hideFloatingWindow()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
            else -> showFloatingWindow()
        }
        return START_STICKY
    }

    private fun showFloatingWindow() {
        if (floatingView != null) {
            floatingView?.visibility = View.VISIBLE
            return
        }

        val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        // KEYBOARD & FOCUS FIX:
        // Do NOT use FLAG_NOT_FOCUSABLE when expanded!
        // Using FLAG_NOT_TOUCH_MODAL allows typing while letting touches outside pass if needed.
        val flags = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutType,
            flags,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 80
            y = 180
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }

        floatingView = ComposeView(this).apply {
            setViewTreeLifecycleOwner(this@FloatingWindowService)
            setViewTreeViewModelStoreOwner(this@FloatingWindowService)
            setViewTreeSavedStateRegistryOwner(this@FloatingWindowService)

            setContent {
                FloatingPopupView(
                    onGenerateNumber = { range ->
                        handleGenerateNumber(range)
                    },
                    onCopyNumber = { num -> copyToClipboard("Phone Number", num) },
                    onCopyOtp = { otp -> copyToClipboard("OTP Code", otp) },
                    onOpenDashboard = {
                        val appIntent = Intent(this@FloatingWindowService, MainActivity::class.java).apply {
                            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
                        }
                        startActivity(appIntent)
                    },
                    onCloseToIcon = {
                        updateFocusFlags(minimized = true)
                        FloatingSessionState.isMinimizedFlow.value = true
                    },
                    onExpandFromIcon = {
                        updateFocusFlags(minimized = false)
                        FloatingSessionState.isMinimizedFlow.value = false
                    },
                    onDragDelta = { dx, dy ->
                        moveWindow(dx, dy)
                    },
                    onDismissService = {
                        hideFloatingWindow()
                        stopSelf()
                    }
                )
            }
        }

        try {
            windowManager.addView(floatingView, params)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun moveWindow(dx: Float, dy: Float) {
        if (floatingView == null) return

        val displayMetrics = resources.displayMetrics
        val screenWidth = displayMetrics.widthPixels
        val screenHeight = displayMetrics.heightPixels

        params.x = (params.x + dx.toInt()).coerceIn(0, screenWidth - 100)
        params.y = (params.y + dy.toInt()).coerceIn(0, screenHeight - 120)

        try {
            windowManager.updateViewLayout(floatingView, params)
        } catch (_: Exception) {}
    }

    private fun updateFocusFlags(minimized: Boolean) {
        if (floatingView == null) return
        if (minimized) {
            // When minimized to a tiny icon, allow touches outside to pass freely
            params.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        } else {
            // When expanded, allow focus and software keyboard for the text field
            params.flags = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH
        }
        try {
            windowManager.updateViewLayout(floatingView, params)
        } catch (_: Exception) {}
    }

    private fun handleGenerateNumber(range: String) {
        val targetRange = range.ifBlank { "23278XXX" }
        FloatingSessionState.isLoadingFlow.value = true
        FloatingSessionState.statusFlow.value = "Generating number..."

        serviceScope.launch {
            try {
                val response = api.getNumber(apiKey = apiKey, range = targetRange)
                if (response.isSuccessful && response.body()?.success == true) {
                    val body = response.body()!!
                    val num = body.phoneNumber ?: body.number ?: ""
                    val sid = body.sessionId?.toString() ?: ""

                    FloatingSessionState.isLoadingFlow.value = false
                    FloatingSessionState.numberFlow.value = num
                    FloatingSessionState.otpFlow.value = ""
                    FloatingSessionState.statusFlow.value = "Waiting for OTP..."

                    Toast.makeText(this@FloatingWindowService, "Number: $num", Toast.LENGTH_SHORT).show()
                    startOtpPolling(sid)
                } else {
                    val err = response.body()?.message ?: "Failed to generate number"
                    FloatingSessionState.isLoadingFlow.value = false
                    FloatingSessionState.statusFlow.value = err
                    Toast.makeText(this@FloatingWindowService, err, Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                FloatingSessionState.isLoadingFlow.value = false
                FloatingSessionState.statusFlow.value = "Network error"
                Toast.makeText(this@FloatingWindowService, "Network error: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun startOtpPolling(sessionId: String) {
        pollingJob?.cancel()
        pollingJob = serviceScope.launch {
            var attempts = 0
            val maxAttempts = 180

            while (attempts < maxAttempts) {
                try {
                    val res = api.getOtp(apiKey = apiKey, sessionId = sessionId)
                    if (res.isSuccessful && res.body()?.success == true) {
                        val body = res.body()!!
                        if (body.received == true || !body.otp.isNullOrBlank() || !body.code.isNullOrBlank()) {
                            val receivedOtp = body.otp ?: body.code ?: extractOtp(body.sms ?: body.message ?: "")
                            FloatingSessionState.otpFlow.value = receivedOtp
                            FloatingSessionState.statusFlow.value = "OTP Received!"

                            notificationHelper.showOtpNotification(
                                number = FloatingSessionState.numberFlow.value,
                                otp = receivedOtp
                            )
                            break
                        }
                    }
                } catch (_: Exception) {}
                delay(1200)
                attempts++
            }
        }
    }

    private fun extractOtp(text: String): String {
        val dashed = Regex("\\b\\d{3}-\\d{3}\\b").find(text)
        if (dashed != null) return dashed.value
        val digits = Regex("\\b\\d{4,8}\\b").find(text)
        return digits?.value ?: "OTP"
    }

    private fun hideFloatingWindow() {
        pollingJob?.cancel()
        floatingView?.let {
            try {
                windowManager.removeView(it)
            } catch (e: Exception) {
                e.printStackTrace()
            }
            floatingView = null
        }
    }

    private fun copyToClipboard(label: String, text: String) {
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText(label, text)
        clipboard.setPrimaryClip(clip)
        Toast.makeText(this, "$label copied!", Toast.LENGTH_SHORT).show()
    }

    private fun buildForegroundNotification(): Notification {
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("SMSIFYHUB Active")
            .setContentText("Overlay window running for real-time OTP updates")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "SMSIFYHUB Floating Service",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        hideFloatingWindow()
        serviceScope.cancel()
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_PAUSE)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_STOP)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_DESTROY)
        appViewModelStore.clear()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
