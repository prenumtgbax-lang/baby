package com.smsifyhub.app.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ConsoleScreen(
    viewModel: SmsifyViewModel
) {
    val consoleState by viewModel.consoleState.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val primaryBlue = Color(0xFF0284C7)
    val textPrimary = Color(0xFF0F172A)
    val textSecondary = Color(0xFF64748B)
    val cardBorder = Color(0xFFE2E8F0)

    var searchQuery by remember { mutableStateOf("") }
    var viewRawJson by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        if (consoleState.rawJson.isBlank()) {
            viewModel.loadConsoleFeed()
        }
    }

    fun copyText(label: String, text: String) {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText(label, text)
        clipboard.setPrimaryClip(clip)
        Toast.makeText(context, "$label copied!", Toast.LENGTH_SHORT).show()
    }

    // Filter messages based on search query
    val filteredMessages = remember(consoleState.messages, searchQuery) {
        if (searchQuery.isBlank()) {
            consoleState.messages
        } else {
            consoleState.messages.filter { item ->
                (item.number?.contains(searchQuery, ignoreCase = true) == true) ||
                (item.operator?.contains(searchQuery, ignoreCase = true) == true) ||
                (item.country?.contains(searchQuery, ignoreCase = true) == true) ||
                (item.range?.contains(searchQuery, ignoreCase = true) == true) ||
                (item.sms?.contains(searchQuery, ignoreCase = true) == true) ||
                (item.app?.contains(searchQuery, ignoreCase = true) == true)
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF8FAFC))
            .padding(16.dp)
    ) {
        // Top Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = Icons.Default.Terminal, contentDescription = null, tint = primaryBlue, modifier = Modifier.size(24.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "LIVE CONSOLE",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Black,
                    color = textPrimary,
                    letterSpacing = 1.sp
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = {
                    viewModel.loadConsoleFeed()
                    Toast.makeText(context, "Refreshing console...", Toast.LENGTH_SHORT).show()
                }) {
                    Icon(imageVector = Icons.Default.Refresh, contentDescription = "Refresh", tint = primaryBlue)
                }

                IconButton(onClick = { viewRawJson = !viewRawJson }) {
                    Icon(
                        imageVector = if (viewRawJson) Icons.Default.List else Icons.Default.DataObject,
                        contentDescription = "Toggle View",
                        tint = textSecondary
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Search Input Field
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("Search by country, number, operator, OTP...", fontSize = 12.sp, color = textSecondary) },
            leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = null, tint = textSecondary, modifier = Modifier.size(18.dp)) },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { searchQuery = "" }) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Clear", tint = textSecondary, modifier = Modifier.size(16.dp))
                    }
                }
            },
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp),
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = Color.White,
                unfocusedContainerColor = Color.White,
                focusedBorderColor = primaryBlue,
                unfocusedBorderColor = cardBorder
            )
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Stats Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Card(
                modifier = Modifier.weight(1f),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, cardBorder)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text("LATENCY", fontSize = 9.sp, color = textSecondary, fontWeight = FontWeight.Bold)
                    Text("${consoleState.responseTimeMs} ms", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = primaryBlue)
                }
            }

            Card(
                modifier = Modifier.weight(1f),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, cardBorder)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text("TOTAL HITS", fontSize = 9.sp, color = textSecondary, fontWeight = FontWeight.Bold)
                    Text("${consoleState.totalHits}", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = textPrimary)
                }
            }

            Card(
                modifier = Modifier.weight(1f),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, cardBorder)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text("RANGES", fontSize = 9.sp, color = textSecondary, fontWeight = FontWeight.Bold)
                    Text("${consoleState.activeRanges.size}", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(0xFF7C3AED))
                }
            }
        }

        // Active Ranges (Click to copy)
        if (consoleState.activeRanges.isNotEmpty()) {
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                consoleState.activeRanges.take(4).forEach { range ->
                    SuggestionChip(
                        onClick = { copyText("Range", range) },
                        label = { Text(range, fontSize = 10.sp, fontWeight = FontWeight.Bold) }
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Main Console Area (Raw JSON or Formatted Message List)
        if (viewRawJson) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(12.dp))
                    .background(Color(0xFF0F172A))
                    .padding(12.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                if (consoleState.isLoading) {
                    CircularProgressIndicator(color = Color(0xFF38BDF8), modifier = Modifier.align(Alignment.Center))
                } else if (consoleState.errorMessage.isNotBlank()) {
                    Text("Error: " + consoleState.errorMessage, color = Color(0xFFF87171), modifier = Modifier.align(Alignment.Center))
                } else {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            TextButton(onClick = { copyText("Console JSON", consoleState.rawJson) }) {
                                Icon(imageVector = Icons.Default.ContentCopy, contentDescription = null, tint = Color(0xFF38BDF8), modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Copy JSON", color = Color(0xFF38BDF8), fontSize = 11.sp)
                            }
                        }
                        Text(
                            text = if (consoleState.rawJson.isNotBlank()) consoleState.rawJson else "No console response loaded. Tap Refresh above.",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            color = Color(0xFF38BDF8)
                        )
                    }
                }
            }
        } else {
            // Formatted Feed List
            if (consoleState.isLoading) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = primaryBlue)
                }
            } else if (consoleState.errorMessage.isNotBlank()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(text = consoleState.errorMessage, color = Color.Red, fontSize = 13.sp)
                }
            } else if (filteredMessages.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(imageVector = Icons.Default.Inbox, contentDescription = null, tint = textSecondary, modifier = Modifier.size(36.dp))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = if (searchQuery.isNotEmpty()) "No matching records found" else "No recent messages in feed",
                            color = textSecondary,
                            fontSize = 12.sp
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(filteredMessages) { msg ->
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            border = BorderStroke(1.dp, cardBorder),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(text = msg.flag ?: "🌐", fontSize = 14.sp)
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = msg.country ?: "Global",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp,
                                            color = textPrimary
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "• ${msg.operator ?: "Carrier"}",
                                            fontSize = 11.sp,
                                            color = textSecondary
                                        )
                                    }

                                    IconButton(
                                        onClick = { copyText("SMS", msg.sms ?: msg.number ?: "") },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(imageVector = Icons.Default.ContentCopy, contentDescription = "Copy", tint = primaryBlue, modifier = Modifier.size(16.dp))
                                    }
                                }

                                Spacer(modifier = Modifier.height(4.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = msg.number ?: "Unknown Number",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = primaryBlue,
                                        fontFamily = FontFamily.Monospace
                                    )
                                    Text(
                                        text = msg.time ?: "Just now",
                                        fontSize = 10.sp,
                                        color = textSecondary
                                    )
                                }

                                if (!msg.sms.isNullOrBlank()) {
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(Color(0xFFF1F5F9), RoundedCornerShape(8.dp))
                                            .padding(8.dp)
                                    ) {
                                        Text(
                                            text = msg.sms,
                                            fontSize = 11.sp,
                                            color = textPrimary
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
