package com.smsifyhub.app

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.smsifyhub.app.service.FloatingWindowService
import com.smsifyhub.app.ui.AuthScreen
import com.smsifyhub.app.ui.ConsoleScreen
import com.smsifyhub.app.ui.DashboardScreen
import com.smsifyhub.app.ui.DevPageScreen
import com.smsifyhub.app.ui.ProfileScreen
import com.smsifyhub.app.ui.SmsifyViewModel
import com.smsifyhub.app.ui.SplashScreen
import com.smsifyhub.app.ui.theme.SMSIFYHUBTheme

enum class MainTab(val title: String, val icon: ImageVector) {
    DASHBOARD("Dashboard", Icons.Default.Dashboard),
    CONSOLE("Console", Icons.Default.Terminal),
    PROFILE("Profile", Icons.Default.Person),
    DEV_PAGE("Dev Page", Icons.Default.Code)
}

class MainActivity : ComponentActivity() {

    private val viewModel: SmsifyViewModel by viewModels()

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (!isGranted) {
            Toast.makeText(this, "Notifications disabled. Alerts won't show in background.", Toast.LENGTH_SHORT).show()
        }
    }

    private val overlayPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        if (Settings.canDrawOverlays(this)) {
            startFloatingWindowService()
            viewModel.setFloatingPopupEnabled(true)
        } else {
            viewModel.setFloatingPopupEnabled(false)
            Toast.makeText(this, "Overlay permission is required for Floating Popup window", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        setContent {
            SMSIFYHUBTheme {
                var currentScreen by remember { mutableStateOf("splash") }
                var selectedTab by remember { mutableStateOf(MainTab.DASHBOARD) }

                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color.White
                ) {
                    Crossfade(targetState = currentScreen, label = "app_navigation") { screen ->
                        when (screen) {
                            "splash" -> {
                                SplashScreen(
                                    viewModel = viewModel,
                                    onSplashFinished = { isLoggedIn ->
                                        currentScreen = if (isLoggedIn) "main" else "auth"
                                    }
                                )
                            }
                            "auth" -> {
                                AuthScreen(
                                    viewModel = viewModel,
                                    onAuthSuccess = {
                                        currentScreen = "main"
                                        selectedTab = MainTab.DASHBOARD
                                    }
                                )
                            }
                            "main" -> {
                                Scaffold(
                                    bottomBar = {
                                        NavigationBar(
                                            containerColor = Color.White,
                                            tonalElevation = 8.dp
                                        ) {
                                            MainTab.entries.forEach { tab ->
                                                NavigationBarItem(
                                                    selected = selectedTab == tab,
                                                    onClick = { selectedTab = tab },
                                                    icon = {
                                                        Icon(
                                                            imageVector = tab.icon,
                                                            contentDescription = tab.title,
                                                            modifier = Modifier.size(20.dp)
                                                        )
                                                    },
                                                    label = {
                                                        Text(
                                                            text = tab.title,
                                                            fontSize = 11.sp
                                                        )
                                                    },
                                                    colors = NavigationBarItemDefaults.colors(
                                                        selectedIconColor = Color(0xFF0284C7),
                                                        selectedTextColor = Color(0xFF0284C7),
                                                        indicatorColor = Color(0xFFE0F2FE),
                                                        unselectedIconColor = Color(0xFF64748B),
                                                        unselectedTextColor = Color(0xFF64748B)
                                                    )
                                                )
                                            }
                                        }
                                    }
                                ) { innerPadding ->
                                    Box(
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .padding(innerPadding)
                                    ) {
                                        when (selectedTab) {
                                            MainTab.DASHBOARD -> DashboardScreen(
                                                viewModel = viewModel,
                                                onToggleFloatingPopup = { enable ->
                                                    handleToggleFloatingPopup(enable)
                                                },
                                                onNavigateToConsole = {
                                                    selectedTab = MainTab.CONSOLE
                                                }
                                            )
                                            MainTab.CONSOLE -> ConsoleScreen(
                                                viewModel = viewModel
                                            )
                                            MainTab.PROFILE -> ProfileScreen(
                                                viewModel = viewModel,
                                                onLoggedOut = {
                                                    stopFloatingWindowService()
                                                    currentScreen = "auth"
                                                }
                                            )
                                            MainTab.DEV_PAGE -> DevPageScreen()
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    private fun handleToggleFloatingPopup(enable: Boolean) {
        if (enable) {
            if (Settings.canDrawOverlays(this)) {
                startFloatingWindowService()
                viewModel.setFloatingPopupEnabled(true)
            } else {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                overlayPermissionLauncher.launch(intent)
            }
        } else {
            stopFloatingWindowService()
            viewModel.setFloatingPopupEnabled(false)
        }
    }

    private fun startFloatingWindowService() {
        val intent = Intent(this, FloatingWindowService::class.java).apply {
            action = FloatingWindowService.ACTION_SHOW
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
    }

    private fun stopFloatingWindowService() {
        val intent = Intent(this, FloatingWindowService::class.java).apply {
            action = FloatingWindowService.ACTION_STOP
        }
        startService(intent)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
    }

    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        super.onRestoreInstanceState(savedInstanceState)
    }
}

