package com.smsifyhub.app.data

import com.google.firebase.database.IgnoreExtraProperties

@IgnoreExtraProperties
data class UserProfile(
    val uid: String = "",
    val fullName: String = "",
    val mobileNumber: String = "",
    val joinDate: String = "",
    val verificationStatus: String = "Verified Hub Member",
    val soundEnabled: Boolean = true,
    val targetRange: String = "23278XXX",
    val lastLoginTimestamp: Long = 0L
) {
    // Masked phone for UI display (e.g., +880 17****5678 or 232****123)
    val maskedPhone: String
        get() {
            val digits = mobileNumber.filter { it.isDigit() || it == '+' }
            return if (digits.length > 6) {
                val prefix = digits.take(4)
                val suffix = digits.takeLast(3)
                "$prefix****$suffix"
            } else {
                digits
            }
        }
}
