package com.smsifyhub.app.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle

@Composable
fun FloatingPopupView(
    onGenerateNumber: (String) -> Unit,
    onCopyNumber: (String) -> Unit,
    onCopyOtp: (String) -> Unit,
    onOpenDashboard: () -> Unit,
    onCloseToIcon: () -> Unit,
    onExpandFromIcon: () -> Unit,
    onDragDelta: (Float, Float) -> Unit,
    onDismissService: () -> Unit
) {
    val number by FloatingSessionState.numberFlow.collectAsStateWithLifecycle()
    val otp by FloatingSessionState.otpFlow.collectAsStateWithLifecycle()
    val status by FloatingSessionState.statusFlow.collectAsStateWithLifecycle()
    val isLoading by FloatingSessionState.isLoadingFlow.collectAsStateWithLifecycle()
    val isMinimized by FloatingSessionState.isMinimizedFlow.collectAsStateWithLifecycle()

    var inputPopupRange by remember { mutableStateOf("23278XXX") }
    val focusManager = LocalFocusManager.current
    val keyboardController = LocalSoftwareKeyboardController.current

    val primaryBlue = Color(0xFF0284C7)
    val orangeGlow = Color(0xFFEA580C)
    val textPrimary = Color(0xFF0F172A)
    val textSecondary = Color(0xFF64748B)
    val cardBorder = Color(0xFFE2E8F0)
    val lightBg = Color(0xFFF8FAFC)

    if (isMinimized) {
        // --- 1. MINIMIZED FLOATING ICON (Movable / Draggable, White + Cyan/Orange Glow) ---
        Box(
            modifier = Modifier
                .size(62.dp)
                .pointerInput(Unit) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        onDragDelta(dragAmount.x, dragAmount.y)
                    }
                }
                .clip(CircleShape)
                .background(Color.White)
                .border(2.5.dp, if (otp.isNotBlank()) orangeGlow else primaryBlue, CircleShape)
                .clickable { onExpandFromIcon() },
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = if (otp.isNotBlank()) Icons.Default.Bolt else Icons.Default.MarkChatRead,
                    contentDescription = "SMSIFYHUB",
                    tint = if (otp.isNotBlank()) orangeGlow else primaryBlue,
                    modifier = Modifier.size(24.dp)
                )
                Text(
                    text = if (otp.isNotBlank()) "OTP!" else "HUB",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = if (otp.isNotBlank()) orangeGlow else textPrimary
                )
            }

            // Notification indicator badge when OTP is ready
            if (otp.isNotBlank()) {
                Box(
                    modifier = Modifier
                        .size(14.dp)
                        .align(Alignment.TopEnd)
                        .clip(CircleShape)
                        .background(Color(0xFFFF3D00))
                        .border(1.5.dp, Color.White, CircleShape)
                )
            }
        }
    } else {
        // --- 2. EXPANDED POPUP (Fully Editable, Draggable Header, Responsive) ---
        Card(
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
            border = BorderStroke(1.5.dp, if (otp.isNotBlank()) orangeGlow else primaryBlue),
            modifier = Modifier
                .width(300.dp)
                .wrapContentHeight()
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header Bar with Drag Handle + Title + Actions
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .pointerInput(Unit) {
                            detectDragGestures { change, dragAmount ->
                                change.consume()
                                onDragDelta(dragAmount.x, dragAmount.y)
                            }
                        }
                        .background(Color(0xFFF1F5F9), RoundedCornerShape(10.dp))
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.DragIndicator,
                            contentDescription = "Drag Popup",
                            tint = textSecondary,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "SMSIFYHUB POPUP",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 0.5.sp,
                            color = textPrimary
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = onCloseToIcon,
                            modifier = Modifier.size(26.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Minimize,
                                contentDescription = "Minimize to Floating Icon",
                                tint = textSecondary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        IconButton(
                            onClick = onDismissService,
                            modifier = Modifier.size(26.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Close Overlay",
                                tint = Color(0xFFEF4444),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // IN-POPUP GET NUMBER SYSTEM — 100% Working Keyboard Input
                Text(
                    text = "TARGET RANGE & GENERATOR",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = primaryBlue,
                    modifier = Modifier.align(Alignment.Start)
                )

                Spacer(modifier = Modifier.height(4.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    OutlinedTextField(
                        value = inputPopupRange,
                        onValueChange = { inputPopupRange = it },
                        singleLine = true,
                        placeholder = { Text("e.g. 23278XXX", fontSize = 12.sp, color = textSecondary) },
                        modifier = Modifier
                            .weight(1f)
                            .heightIn(min = 48.dp),
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Text,
                            imeAction = ImeAction.Done
                        ),
                        keyboardActions = KeyboardActions(
                            onDone = {
                                keyboardController?.hide()
                                focusManager.clearFocus()
                                onGenerateNumber(inputPopupRange)
                            }
                        ),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = textPrimary,
                            unfocusedTextColor = textPrimary,
                            focusedBorderColor = primaryBlue,
                            unfocusedBorderColor = cardBorder,
                            focusedContainerColor = lightBg,
                            unfocusedContainerColor = lightBg
                        ),
                        shape = RoundedCornerShape(10.dp)
                    )

                    Button(
                        onClick = {
                            keyboardController?.hide()
                            focusManager.clearFocus()
                            onGenerateNumber(inputPopupRange)
                        },
                        enabled = !isLoading,
                        modifier = Modifier.height(48.dp),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = primaryBlue)
                    ) {
                        if (isLoading) {
                            CircularProgressIndicator(color = Color.White, modifier = Modifier.size(16.dp))
                        } else {
                            Text("GET", fontSize = 12.sp, fontWeight = FontWeight.Black)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Generated Phone Number Section
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(lightBg)
                        .border(1.dp, cardBorder, RoundedCornerShape(10.dp))
                        .padding(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "ACTIVE NUMBER",
                                fontSize = 9.sp,
                                color = textSecondary,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (number.isNotBlank()) number else "Ready — tap GET above",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = textPrimary,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        Button(
                            onClick = { onCopyNumber(number) },
                            enabled = number.isNotBlank(),
                            modifier = Modifier.height(30.dp),
                            shape = RoundedCornerShape(6.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = primaryBlue)
                        ) {
                            Text("COPY", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // OTP Row (Glows vibrant orange instantly when received)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (otp.isNotBlank()) Color(0xFFFFF7ED) else lightBg)
                        .border(1.5.dp, if (otp.isNotBlank()) orangeGlow else cardBorder, RoundedCornerShape(10.dp))
                        .padding(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (otp.isNotBlank()) "⚡ OTP RECEIVED" else "STATUS: ${status.take(18)}",
                                fontSize = 9.sp,
                                color = if (otp.isNotBlank()) orangeGlow else textSecondary,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (otp.isNotBlank()) otp else "••••••",
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 2.sp,
                                color = if (otp.isNotBlank()) orangeGlow else Color.LightGray,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        Button(
                            onClick = { onCopyOtp(otp) },
                            enabled = otp.isNotBlank(),
                            modifier = Modifier.height(30.dp),
                            shape = RoundedCornerShape(6.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = orangeGlow)
                        ) {
                            Text("COPY", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Bottom Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = onOpenDashboard,
                        modifier = Modifier
                            .weight(1.3f)
                            .height(36.dp),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0F172A)),
                        contentPadding = PaddingValues(0.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Dashboard, contentDescription = null, modifier = Modifier.size(14.dp), tint = Color.White)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("DASHBOARD", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }

                    OutlinedButton(
                        onClick = onCloseToIcon,
                        modifier = Modifier
                            .weight(1f)
                            .height(36.dp),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(0.dp)
                    ) {
                        Text("MINIMIZE", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = textPrimary)
                    }
                }
            }
        }
    }
}
