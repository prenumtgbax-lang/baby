package com.smsifyhub.app.data

import android.content.Context
import android.content.SharedPreferences
import com.google.firebase.auth.EmailAuthProvider
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class AuthRepository(private val context: Context) {

    private val auth: FirebaseAuth by lazy { FirebaseAuth.getInstance() }
    private val database: FirebaseDatabase by lazy {
        FirebaseDatabase.getInstance("https://daliyjobs-f523c-default-rtdb.firebaseio.com").apply {
            try {
                setPersistenceEnabled(true)
            } catch (_: Exception) {
                // Ignore if already enabled
            }
        }
    }

    private val prefs: SharedPreferences = context.getSharedPreferences("smsify_auth_prefs", Context.MODE_PRIVATE)

    private val _currentUser = MutableStateFlow<UserProfile?>(null)
    val currentUser: StateFlow<UserProfile?> = _currentUser.asStateFlow()

    init {
        // Load cached user profile initially
        val cachedUid = prefs.getString("cached_uid", null)
        if (cachedUid != null && auth.currentUser != null) {
            val cachedProfile = UserProfile(
                uid = cachedUid,
                fullName = prefs.getString("cached_name", "") ?: "",
                mobileNumber = prefs.getString("cached_phone", "") ?: "",
                joinDate = prefs.getString("cached_join_date", "") ?: "",
                verificationStatus = prefs.getString("cached_status", "Verified Hub Member") ?: "Verified Hub Member",
                soundEnabled = prefs.getBoolean("cached_sound", true),
                targetRange = prefs.getString("cached_range", "23278XXX") ?: "23278XXX"
            )
            _currentUser.value = cachedProfile
        }
    }

    private fun phoneToEmail(phone: String): String {
        val cleanDigits = phone.filter { it.isDigit() }
        return "u_${cleanDigits}@smsifyhub.app"
    }

    fun isUserLoggedIn(): Boolean {
        return auth.currentUser != null
    }

    suspend fun register(fullName: String, mobileNumber: String, password: String):Result<UserProfile> = withContext(Dispatchers.IO) {
        try {
            val cleanPhone = mobileNumber.trim()
            val digits = cleanPhone.filter { it.isDigit() }
            if (fullName.isBlank()) {
                return@withContext Result.failure(IllegalArgumentException("Please enter your full name"))
            }
            if (digits.length < 8) {
                return@withContext Result.failure(IllegalArgumentException("Please enter a valid mobile number (at least 8 digits)"))
            }
            if (password.length < 6) {
                return@withContext Result.failure(IllegalArgumentException("Password must be at least 6 characters"))
            }

            val email = phoneToEmail(digits)
            val authResult = auth.createUserWithEmailAndPassword(email, password).await()
            val uid = authResult.user?.uid ?: throw IllegalStateException("Firebase UID could not be generated")

            val joinDate = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(Date())
            val profile = UserProfile(
                uid = uid,
                fullName = fullName.trim(),
                mobileNumber = cleanPhone,
                joinDate = joinDate,
                verificationStatus = "Verified Hub Member",
                soundEnabled = true,
                targetRange = "23278XXX",
                lastLoginTimestamp = System.currentTimeMillis()
            )

            // Persist to Firebase Realtime Database
            database.getReference("users").child(uid).setValue(profile).await()

            // Cache locally
            cacheProfileLocally(profile)
            _currentUser.value = profile

            Result.success(profile)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun login(mobileNumber: String, password: String): Result<UserProfile> = withContext(Dispatchers.IO) {
        try {
            val cleanPhone = mobileNumber.trim()
            val digits = cleanPhone.filter { it.isDigit() }
            if (digits.length < 8) {
                return@withContext Result.failure(IllegalArgumentException("Please enter a valid mobile number"))
            }
            if (password.isBlank()) {
                return@withContext Result.failure(IllegalArgumentException("Please enter your password"))
            }

            val email = phoneToEmail(digits)
            val authResult = auth.signInWithEmailAndPassword(email, password).await()
            val uid = authResult.user?.uid ?: throw IllegalStateException("User sign-in failed")

            // Retrieve profile from Firebase
            var profile: UserProfile? = null
            try {
                val snapshot = database.getReference("users").child(uid).get().await()
                profile = snapshot.getValue(UserProfile::class.java)
            } catch (_: Exception) {
                // If offline or first-time read, build fallback
            }

            if (profile == null) {
                val joinDate = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(Date())
                profile = UserProfile(
                    uid = uid,
                    fullName = "SMSIFY Member",
                    mobileNumber = cleanPhone,
                    joinDate = joinDate,
                    verificationStatus = "Verified Hub Member",
                    soundEnabled = true,
                    targetRange = "23278XXX",
                    lastLoginTimestamp = System.currentTimeMillis()
                )
                try {
                    database.getReference("users").child(uid).setValue(profile).await()
                } catch (_: Exception) {}
            }

            cacheProfileLocally(profile)
            _currentUser.value = profile

            Result.success(profile)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun updateProfile(fullName: String, soundEnabled: Boolean, targetRange: String = ""): Result<UserProfile> = withContext(Dispatchers.IO) {
        try {
            val current = _currentUser.value ?: return@withContext Result.failure(IllegalStateException("No authenticated user"))
            val updated = current.copy(
                fullName = if (fullName.isNotBlank()) fullName.trim() else current.fullName,
                soundEnabled = soundEnabled,
                targetRange = if (targetRange.isNotBlank()) targetRange.trim() else current.targetRange
            )

            database.getReference("users").child(current.uid).setValue(updated).await()
            cacheProfileLocally(updated)
            _currentUser.value = updated

            Result.success(updated)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun changePassword(oldPassword: String, newPassword: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val user = auth.currentUser ?: return@withContext Result.failure(IllegalStateException("Not logged in"))
            val email = user.email ?: return@withContext Result.failure(IllegalStateException("Missing auth email"))

            if (newPassword.length < 6) {
                return@withContext Result.failure(IllegalArgumentException("New password must be at least 6 characters"))
            }

            // Re-authenticate user
            val credential = EmailAuthProvider.getCredential(email, oldPassword)
            user.reauthenticate(credential).await()

            // Update to new password
            user.updatePassword(newPassword).await()

            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun logout() {
        auth.signOut()
        _currentUser.value = null
        prefs.edit().clear().apply()
    }

    fun isSoundEnabled(): Boolean {
        return _currentUser.value?.soundEnabled ?: prefs.getBoolean("cached_sound", true)
    }

    private fun cacheProfileLocally(profile: UserProfile) {
        prefs.edit()
            .putString("cached_uid", profile.uid)
            .putString("cached_name", profile.fullName)
            .putString("cached_phone", profile.mobileNumber)
            .putString("cached_join_date", profile.joinDate)
            .putString("cached_status", profile.verificationStatus)
            .putBoolean("cached_sound", profile.soundEnabled)
            .putString("cached_range", profile.targetRange)
            .apply()
    }
}
