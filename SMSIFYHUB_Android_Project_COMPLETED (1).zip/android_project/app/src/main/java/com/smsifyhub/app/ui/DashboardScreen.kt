package com.smsifyhub.app.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.smsifyhub.app.R

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    viewModel: SmsifyViewModel,
    onToggleFloatingPopup: (Boolean) -> Unit,
    onNavigateToConsole: () -> Unit
) {
    val sessionState by viewModel.sessionState.collectAsStateWithLifecycle()
    val userProfile by viewModel.currentUser.collectAsStateWithLifecycle()
    val floatingEnabled by viewModel.floatingPopupEnabled.collectAsStateWithLifecycle()
    val context = LocalContext.current

    var inputTargetRange by remember { mutableStateOf(userProfile?.targetRange ?: "23278XXX") }

    val primaryBlue = Color(0xFF0284C7)
    val textPrimary = Color(0xFF0F172A)
    val textSecondary = Color(0xFF64748B)
    val cardBorder = Color(0xFFE2E8F0)
    val orangeAccent = Color(0xFFEA580C)

    val quickRanges = listOf("23278XXX", "23762XXX", "22465XXX", "2290145XXX", "22897XXX")

    fun copyText(label: String, text: String) {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText(label, text)
        clipboard.setPrimaryClip(clip)
        Toast.makeText(context, "$label copied!", Toast.LENGTH_SHORT).show()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // App Top Bar Branding
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFE0F2FE)),
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.app_logo),
                        contentDescription = "SMSIFYHUB",
                        modifier = Modifier.size(30.dp).clip(CircleShape)
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = "SMSIFYHUB",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.sp,
                        color = textPrimary
                    )
                    Text(
                        text = "FAST • SAFE • RELIABLE",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = primaryBlue,
                        letterSpacing = 1.sp
                    )
                }
            }

            AssistChip(
                onClick = {},
                label = { Text("ONLINE", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                leadingIcon = {
                    Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(Color(0xFF10B981)))
                },
                colors = AssistChipDefaults.assistChipColors(containerColor = Color(0xFFF0FDF4), labelColor = Color(0xFF15803D))
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // 1. Logged-in User Information Card (Requirement 6)
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFFF8FAFC)),
            border = BorderStroke(1.dp, cardBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFE0F2FE))
                            .border(1.5.dp, primaryBlue, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(imageVector = Icons.Default.Person, contentDescription = null, tint = primaryBlue, modifier = Modifier.size(24.dp))
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = userProfile?.fullName ?: "SMSIFY Member",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = textPrimary
                        )
                        Text(
                            text = userProfile?.maskedPhone ?: "Mobile Active",
                            fontSize = 12.sp,
                            color = textSecondary,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "Joined: ${userProfile?.joinDate ?: "Recently"}",
                            fontSize = 10.sp,
                            color = textSecondary
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFFECFDF5))
                        .border(1.dp, Color(0xFFA7F3D0), RoundedCornerShape(8.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "VERIFIED",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFF059669)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // 2. Floating Popup Toggle Card
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = BorderStroke(1.dp, if (floatingEnabled) primaryBlue else cardBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.PictureInPicture,
                        contentDescription = "Floating Overlay",
                        tint = if (floatingEnabled) primaryBlue else textSecondary,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "FLOATING POPUP OVERLAY",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = textPrimary
                        )
                        Text(
                            text = if (floatingEnabled) "Running • Editable • Draggable" else "Tap switch to enable on-screen popup",
                            fontSize = 10.sp,
                            color = textSecondary
                        )
                    }
                }

                Switch(
                    checked = floatingEnabled,
                    onCheckedChange = { onToggleFloatingPopup(it) },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.White,
                        checkedTrackColor = primaryBlue,
                        uncheckedTrackColor = Color(0xFFE2E8F0)
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // 3. Get Number Section
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = BorderStroke(1.dp, cardBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "GET NUMBER GATEWAY",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF7C3AED),
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "Target Range",
                        fontSize = 10.sp,
                        color = textSecondary
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = inputTargetRange,
                    onValueChange = { inputTargetRange = it },
                    placeholder = { Text("e.g. 23278XXX", color = Color.Gray, fontSize = 13.sp) },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp),
                    shape = RoundedCornerShape(10.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = textPrimary,
                        unfocusedTextColor = textPrimary,
                        focusedBorderColor = primaryBlue,
                        unfocusedBorderColor = cardBorder
                    )
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Quick Range Chips
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    quickRanges.take(4).forEach { range ->
                        SuggestionChip(
                            onClick = { inputTargetRange = range },
                            label = { Text(range, fontSize = 9.sp, fontWeight = FontWeight.Bold) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Button(
                    onClick = { viewModel.requestNumber(inputTargetRange) },
                    enabled = !sessionState.isLoading,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = primaryBlue)
                ) {
                    if (sessionState.isLoading) {
                        CircularProgressIndicator(color = Color.White, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("GENERATING NUMBER...")
                    } else {
                        Icon(imageVector = Icons.Default.PhoneIphone, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("GENERATE NUMBER", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }

                if (sessionState.phoneNumber.isNotBlank()) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFFF1F5F9))
                            .border(1.dp, primaryBlue, RoundedCornerShape(12.dp))
                            .padding(12.dp)
                    ) {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("ASSIGNED NUMBER", fontSize = 10.sp, color = textSecondary, fontWeight = FontWeight.Bold)
                                Text("SESSION #${sessionState.sessionId}", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = primaryBlue)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = sessionState.phoneNumber,
                                fontSize = 20.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = textPrimary,
                                fontFamily = FontFamily.Monospace
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Button(
                                onClick = { copyText("Phone Number", sessionState.phoneNumber) },
                                modifier = Modifier.fillMaxWidth().height(36.dp),
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = primaryBlue)
                            ) {
                                Icon(imageVector = Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("COPY NUMBER", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // 4. OTP Receiving Section
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = BorderStroke(
                1.dp,
                if (sessionState.status == "received") orangeAccent else cardBorder
            ),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "LIVE OTP RECEPTOR",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = orangeAccent,
                        letterSpacing = 1.sp
                    )

                    if (sessionState.status == "waiting") {
                        Text(
                            text = "${sessionState.elapsedSeconds}s",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = primaryBlue
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                when (sessionState.status) {
                    "waiting" -> {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(Color(0xFFFFF7ED))
                                .border(1.dp, Color(0xFFFDBA74), RoundedCornerShape(10.dp))
                                .padding(14.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                CircularProgressIndicator(color = orangeAccent, modifier = Modifier.size(30.dp))
                                Spacer(modifier = Modifier.height(6.dp))
                                Text("Waiting for incoming OTP...", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = textPrimary)
                                Text("Polling active gateway automatically", fontSize = 10.sp, color = textSecondary)
                            }
                        }
                    }
                    "received" -> {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(Color(0xFFFFF7ED))
                                .border(2.dp, orangeAccent, RoundedCornerShape(10.dp))
                                .padding(14.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("⚡ OTP RECEIVED INSTANTLY", color = orangeAccent, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = sessionState.otp,
                                    fontSize = 28.sp,
                                    fontWeight = FontWeight.Black,
                                    letterSpacing = 4.sp,
                                    color = orangeAccent,
                                    fontFamily = FontFamily.Monospace
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Button(
                                    onClick = { copyText("OTP Code", sessionState.otp) },
                                    colors = ButtonDefaults.buttonColors(containerColor = orangeAccent),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.fillMaxWidth().height(38.dp)
                                ) {
                                    Icon(imageVector = Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("COPY OTP", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                }
                            }
                        }
                    }
                    else -> {
                        Text(
                            text = if (sessionState.phoneNumber.isBlank()) "Generate a number above to start listening for OTP" else "Session status: ${sessionState.status}",
                            fontSize = 11.sp,
                            color = textSecondary
                        )
                    }
                }

                if (sessionState.smsText.isNotBlank()) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = "Message: " + sessionState.smsText, fontSize = 11.sp, color = textPrimary)
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedButton(
                        onClick = { copyText("SMS Message", sessionState.smsText) },
                        modifier = Modifier.fillMaxWidth().height(34.dp),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("COPY MESSAGE", fontSize = 11.sp)
                    }
                }

                if (sessionState.phoneNumber.isNotBlank() && sessionState.otp.isBlank()) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = {
                                viewModel.refreshOtpManual()
                                Toast.makeText(context, "Checking gateway...", Toast.LENGTH_SHORT).show()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = primaryBlue),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f).height(38.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Check OTP", fontSize = 11.sp)
                        }
                        OutlinedButton(
                            onClick = {
                                if (sessionState.status == "waiting") {
                                    viewModel.stopWaiting()
                                } else {
                                    viewModel.requestNumber(inputTargetRange)
                                }
                            },
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f).height(38.dp)
                        ) {
                            Text(if (sessionState.status == "waiting") "Stop Session" else "Restart", fontSize = 11.sp)
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))
    }
}
