package com.smsifyhub.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.smsifyhub.app.data.ApiService
import com.smsifyhub.app.data.AuthRepository
import com.smsifyhub.app.data.ConsoleFeedResponseDto
import com.smsifyhub.app.data.UserProfile
import com.smsifyhub.app.util.NotificationHelper
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class ActiveSessionUiState(
    val sessionId: String = "",
    val phoneNumber: String = "",
    val range: String = "23278XXX",
    val status: String = "idle", // idle, requesting, waiting, received, stopped, error
    val otp: String = "",
    val smsText: String = "",
    val elapsedSeconds: Int = 0,
    val isLoading: Boolean = false,
    val errorMessage: String = ""
)

data class ConsoleUiState(
    val isLoading: Boolean = false,
    val rawJson: String = "",
    val responseTimeMs: Long = 0,
    val totalHits: Int = 0,
    val activeRanges: List<String> = emptyList(),
    val messages: List<com.smsifyhub.app.data.ConsoleTrafficItemDto> = emptyList(),
    val errorMessage: String = ""
)

data class AuthUiState(
    val isLoading: Boolean = false,
    val errorMessage: String = "",
    val successMessage: String = ""
)

object FloatingSessionState {
    val numberFlow = MutableStateFlow("")
    val otpFlow = MutableStateFlow("")
    val statusFlow = MutableStateFlow("Idle")
    val isLoadingFlow = MutableStateFlow(false)
    val isVisibleFlow = MutableStateFlow(false)
    val isMinimizedFlow = MutableStateFlow(false)
}

class SmsifyViewModel(application: Application) : AndroidViewModel(application) {

    val authRepository = AuthRepository(application)
    private val api = ApiService.create()
    private val notificationHelper = NotificationHelper(application)
    private val apiKey = "smsify_7ee5a9cfa1a113e6d7b799ea"

    val currentUser: StateFlow<UserProfile?> = authRepository.currentUser

    private val _authUiState = MutableStateFlow(AuthUiState())
    val authUiState: StateFlow<AuthUiState> = _authUiState.asStateFlow()

    private val _sessionState = MutableStateFlow(ActiveSessionUiState())
    val sessionState: StateFlow<ActiveSessionUiState> = _sessionState.asStateFlow()

    private val _consoleState = MutableStateFlow(ConsoleUiState())
    val consoleState: StateFlow<ConsoleUiState> = _consoleState.asStateFlow()

    private val _floatingPopupEnabled = MutableStateFlow(false)
    val floatingPopupEnabled: StateFlow<Boolean> = _floatingPopupEnabled.asStateFlow()

    private var pollingJob: Job? = null
    private var timerJob: Job? = null

    init {
        // Restore target range from saved user profile
        currentUser.value?.let { profile ->
            if (profile.targetRange.isNotBlank()) {
                _sessionState.update { it.copy(range = profile.targetRange) }
            }
        }
    }

    fun isUserLoggedIn(): Boolean {
        return authRepository.isUserLoggedIn()
    }

    fun clearAuthMessages() {
        _authUiState.update { it.copy(errorMessage = "", successMessage = "") }
    }

    fun register(fullName: String, phone: String, pass: String, confirmPass: String, onSuccess: () -> Unit) {
        if (pass != confirmPass) {
            _authUiState.update { it.copy(errorMessage = "Passwords do not match") }
            return
        }

        _authUiState.update { it.copy(isLoading = true, errorMessage = "", successMessage = "") }
        viewModelScope.launch {
            val result = authRepository.register(fullName, phone, pass)
            result.onSuccess {
                _authUiState.update { it.copy(isLoading = false, successMessage = "Registration successful!") }
                onSuccess()
            }.onFailure { err ->
                val msg = when {
                    err.message?.contains("email address is already in use", ignoreCase = true) == true ->
                        "An account already exists for this mobile number"
                    else -> err.message ?: "Registration failed"
                }
                _authUiState.update { it.copy(isLoading = false, errorMessage = msg) }
            }
        }
    }

    fun login(phone: String, pass: String, onSuccess: () -> Unit) {
        _authUiState.update { it.copy(isLoading = true, errorMessage = "", successMessage = "") }
        viewModelScope.launch {
            val result = authRepository.login(phone, pass)
            result.onSuccess { profile ->
                _authUiState.update { it.copy(isLoading = false, successMessage = "Welcome back, ${profile.fullName}!") }
                if (profile.targetRange.isNotBlank()) {
                    _sessionState.update { it.copy(range = profile.targetRange) }
                }
                onSuccess()
            }.onFailure { err ->
                val msg = when {
                    err.message?.contains("no user record", ignoreCase = true) == true ||
                    err.message?.contains("invalid-credential", ignoreCase = true) == true ->
                        "Incorrect mobile number or password"
                    else -> err.message ?: "Login failed. Check internet and try again."
                }
                _authUiState.update { it.copy(isLoading = false, errorMessage = msg) }
            }
        }
    }

    fun updateProfile(name: String, soundEnabled: Boolean, targetRange: String, onComplete: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            val result = authRepository.updateProfile(name, soundEnabled, targetRange)
            result.onSuccess {
                onComplete(true, "Profile updated successfully")
            }.onFailure { err ->
                onComplete(false, err.message ?: "Failed to update profile")
            }
        }
    }

    fun changePassword(oldPass: String, newPass: String, onComplete: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            val result = authRepository.changePassword(oldPass, newPass)
            result.onSuccess {
                onComplete(true, "Password changed successfully")
            }.onFailure { err ->
                onComplete(false, err.message ?: "Failed to change password")
            }
        }
    }

    fun logout(onLoggedOut: () -> Unit) {
        stopWaiting()
        authRepository.logout()
        // Reset in-memory session states completely
        _sessionState.value = ActiveSessionUiState()
        FloatingSessionState.numberFlow.value = ""
        FloatingSessionState.otpFlow.value = ""
        FloatingSessionState.statusFlow.value = "Idle"
        onLoggedOut()
    }

    fun setFloatingPopupEnabled(enabled: Boolean) {
        _floatingPopupEnabled.value = enabled
        FloatingSessionState.isVisibleFlow.value = enabled
    }

    fun requestNumber(range: String) {
        val targetRange = range.ifBlank { "23278XXX" }

        stopWaiting()
        _sessionState.update {
            it.copy(
                isLoading = true,
                range = targetRange,
                errorMessage = "",
                status = "requesting"
            )
        }
        FloatingSessionState.isLoadingFlow.value = true
        FloatingSessionState.statusFlow.value = "Requesting number..."

        viewModelScope.launch {
            try {
                val response = api.getNumber(apiKey = apiKey, range = targetRange)
                if (response.isSuccessful && response.body()?.success == true) {
                    val body = response.body()!!
                    val num = body.phoneNumber ?: body.number ?: ""
                    val sid = body.sessionId?.toString() ?: ""

                    _sessionState.update {
                        it.copy(
                            isLoading = false,
                            phoneNumber = num,
                            sessionId = sid,
                            status = "waiting",
                            otp = "",
                            smsText = "",
                            elapsedSeconds = 0,
                            errorMessage = ""
                        )
                    }

                    FloatingSessionState.isLoadingFlow.value = false
                    FloatingSessionState.numberFlow.value = num
                    FloatingSessionState.otpFlow.value = ""
                    FloatingSessionState.statusFlow.value = "Waiting for OTP..."

                    // Save selected range preference to Firebase
                    currentUser.value?.let { profile ->
                        if (profile.targetRange != targetRange) {
                            authRepository.updateProfile(profile.fullName, profile.soundEnabled, targetRange)
                        }
                    }

                    startOtpPolling(sid)
                } else {
                    val errMsg = response.body()?.message ?: "Failed to generate number for range $targetRange"
                    _sessionState.update { it.copy(isLoading = false, errorMessage = errMsg, status = "error") }
                    FloatingSessionState.isLoadingFlow.value = false
                    FloatingSessionState.statusFlow.value = errMsg
                }
            } catch (e: Exception) {
                val errMsg = e.message ?: "Network error connecting to Hub"
                _sessionState.update { it.copy(isLoading = false, errorMessage = errMsg, status = "error") }
                FloatingSessionState.isLoadingFlow.value = false
                FloatingSessionState.statusFlow.value = errMsg
            }
        }
    }

    private fun startOtpPolling(sessionId: String) {
        pollingJob?.cancel()
        timerJob?.cancel()

        timerJob = viewModelScope.launch {
            while (true) {
                delay(1000)
                _sessionState.update { it.copy(elapsedSeconds = it.elapsedSeconds + 1) }
            }
        }

        pollingJob = viewModelScope.launch {
            var attempts = 0
            val maxAttempts = 180

            while (attempts < maxAttempts) {
                try {
                    val res = api.getOtp(apiKey = apiKey, sessionId = sessionId)
                    if (res.isSuccessful && res.body()?.success == true) {
                        val body = res.body()!!

                        if (body.received == true || !body.otp.isNullOrBlank() || !body.code.isNullOrBlank()) {
                            val receivedOtp = body.otp ?: body.code ?: extractOtp(body.sms ?: body.message ?: "")
                            val fullSms = body.sms ?: body.message ?: "OTP received for verification"

                            _sessionState.update {
                                it.copy(
                                    status = "received",
                                    otp = receivedOtp,
                                    smsText = fullSms
                                )
                            }

                            FloatingSessionState.otpFlow.value = receivedOtp
                            FloatingSessionState.statusFlow.value = "OTP Received!"

                            notificationHelper.showOtpNotification(
                                number = _sessionState.value.phoneNumber,
                                otp = receivedOtp
                            )
                            stopWaiting()
                            break
                        }
                    }
                } catch (_: Exception) {}
                delay(1200)
                attempts++
            }
        }
    }

    fun stopWaiting() {
        pollingJob?.cancel()
        timerJob?.cancel()
        pollingJob = null
        timerJob = null
        if (_sessionState.value.status == "waiting") {
            _sessionState.update { it.copy(status = "stopped") }
            FloatingSessionState.statusFlow.value = "Stopped"
        }
    }

    fun refreshOtpManual() {
        val sid = _sessionState.value.sessionId
        if (sid.isBlank()) return

        viewModelScope.launch {
            try {
                val res = api.getOtp(apiKey = apiKey, sessionId = sid)
                if (res.isSuccessful && res.body()?.received == true) {
                    val body = res.body()!!
                    val receivedOtp = body.otp ?: body.code ?: extractOtp(body.sms ?: "")
                    _sessionState.update {
                        it.copy(
                            status = "received",
                            otp = receivedOtp,
                            smsText = body.sms ?: ""
                        )
                    }
                    FloatingSessionState.otpFlow.value = receivedOtp
                    FloatingSessionState.statusFlow.value = "OTP Received!"
                }
            } catch (_: Exception) {}
        }
    }

    fun loadConsoleFeed() {
        _consoleState.update { it.copy(isLoading = true, errorMessage = "") }
        val startTime = System.currentTimeMillis()

        viewModelScope.launch {
            try {
                val response = api.getConsoleFeed(apiKey = apiKey)
                val duration = System.currentTimeMillis() - startTime

                if (response.isSuccessful && response.body()?.success == true) {
                    val body = response.body()!!
                    _consoleState.update {
                        it.copy(
                            isLoading = false,
                            rawJson = com.google.gson.GsonBuilder().setPrettyPrinting().create().toJson(body),
                            responseTimeMs = duration,
                            totalHits = body.totalHits ?: 0,
                            activeRanges = body.activeRanges ?: emptyList(),
                            messages = body.messages ?: emptyList()
                        )
                    }
                } else {
                    _consoleState.update {
                        it.copy(
                            isLoading = false,
                            errorMessage = response.body()?.message ?: "Failed to fetch console feed"
                        )
                    }
                }
            } catch (e: Exception) {
                _consoleState.update {
                    it.copy(
                        isLoading = false,
                        errorMessage = e.message ?: "Failed to reach console API"
                    )
                }
            }
        }
    }

    private fun extractOtp(text: String): String {
        val dashed = Regex("\\b\\d{3}-\\d{3}\\b").find(text)
        if (dashed != null) return dashed.value
        val digits = Regex("\\b\\d{4,8}\\b").find(text)
        return digits?.value ?: "OTP"
    }
}
