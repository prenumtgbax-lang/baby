package com.smsifyhub.app.util

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import com.smsifyhub.app.R

object SoundHelper {

    private var mediaPlayer: MediaPlayer? = null

    fun playStartupSound(context: Context, soundEnabled: Boolean) {
        if (!soundEnabled) return

        try {
            val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
            if (audioManager != null) {
                val ringerMode = audioManager.ringerMode
                if (ringerMode == AudioManager.RINGER_MODE_SILENT || ringerMode == AudioManager.RINGER_MODE_VIBRATE) {
                    return
                }
            }

            stopSound()

            mediaPlayer = MediaPlayer.create(context, R.raw.opening_chime)?.apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                        .build()
                )
                setOnCompletionListener { mp ->
                    try {
                        mp.reset()
                        mp.release()
                    } catch (_: Exception) {}
                    if (mediaPlayer == mp) {
                        mediaPlayer = null
                    }
                }
                setOnErrorListener { mp, _, _ ->
                    try {
                        mp.reset()
                        mp.release()
                    } catch (_: Exception) {}
                    if (mediaPlayer == mp) {
                        mediaPlayer = null
                    }
                    true
                }
                start()
            }
        } catch (_: Exception) {
            // Failsafe: avoid crashes if audio device is unavailable
        }
    }

    fun stopSound() {
        try {
            mediaPlayer?.let { mp ->
                if (mp.isPlaying) {
                    mp.stop()
                }
                mp.reset()
                mp.release()
            }
        } catch (_: Exception) {}
        mediaPlayer = null
    }
}
